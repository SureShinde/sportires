var config = {
    'paths': {
        'bootstrap': 'Openpay_Cards/js/bootstrap'
    },
    'shim': {
        'bootstrap': {            
            'deps': ['jquery']
        }
    }
};